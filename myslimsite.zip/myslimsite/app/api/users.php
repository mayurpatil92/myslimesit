<?php
//developed by Mayur Patil
$app->get('/api/users', function(){
	require_once('dbconnect.php');
	
	$query = "select * from employee order by id";
	$result = $mysqli->query($query);
	
	while($row = $result->fetch_assoc()){
		$data[] = $row;
	}
	if(isset($data)){
		header('Context-Type: application/json');
	echo json_encode($data);
	}
});

$app->get('/api/users/{id}', function($request){
	require_once('dbconnect.php');
	
	$id = $request->getAttribute('id');
	
	$query = "select * from employee where id=$id";
	$result = $mysqli->query($query);
	
	$data[] = $result->fetch_assoc();
	header('Context-Type: application/json');
	echo json_encode($data);
	
});

$app->delete('/api/users/{id}', function($request){
	require_once('dbconnect.php');
	$id = $request->getAttribute('id');
	$query = "delete from employee where id=$id";
	$result = $mysqli->query($query);
	
});


